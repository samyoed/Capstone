Mega Deal : 200 Premium Logo Template + 1900 Vector Set + 8 Font : https://crmrkt.com/D3EzkV

NOTE: This font is for PERSONAL USE ONLY! But any donation are very appreciated. 

Paypal account for donation : https://www.paypal.me/putracetol

Link to purchase full version and commercial license : https://creativemarket.com/putracetol?u=putracetol

If there is a problem, question, or anything about my fonts, please sent an email to putra.designer@gmail.com

Thanks,
PutraCetol Studio